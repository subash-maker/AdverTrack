import {
  require_react_dom
} from "./chunk-NUMECXU6.js";
import "./chunk-RLJ2RCJQ.js";
import "./chunk-DC5AMYBS.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
